package demo;
//
////import javafx.beans.property.SimpleStringProperty;
////import javafx.beans.property.StringProperty;
////
////public class Song {
////    private final StringProperty title;
////    private final StringProperty artist;
////    private final StringProperty album;
////    private final StringProperty year;
////    private final StringProperty genre;
////    private final StringProperty comment;
////    private final int id;
////    private final String filePath;
////
////    public Song(String title, String artist, String album, int year, String genre, String comment, int id, String filePath) {
////        this.title = new SimpleStringProperty(title);
////        this.artist = new SimpleStringProperty(artist);
////        this.album = new SimpleStringProperty(album);
////        this.year = new SimpleStringProperty(String.valueOf(year));
////        this.genre = new SimpleStringProperty(genre);
////        this.comment = new SimpleStringProperty(comment);
////        this.id = id;
////        this.filePath = filePath;
////    }
////
////    public String getTitle() { return title.get(); }
////    public StringProperty titleProperty() { return title; }
////
////    public String getArtist() { return artist.get(); }
////    public StringProperty artistProperty() { return artist; }
////
////    public String getAlbum() { return album.get(); }
////    public StringProperty albumProperty() { return album; }
////
////    public int getYear() { return Integer.parseInt(year.get()); }
////    public StringProperty yearProperty() { return year; }
////
////    public String getGenre() { return genre.get(); }
////    public StringProperty genreProperty() { return genre; }
////
////    public String getComment() { return comment.get(); }
////    public StringProperty commentProperty() { return comment; }
////
////    public int getId() { return id; }
////
////    public String getFilePath() { return filePath; }
////}
//public class Song {
//    private int id;
//    private String title;
//    private String artist;
//    private String album;
//    private int year;
//    private String genre;
//    private String comment;
//    private String filepath;
//
//    public Song(int id, String title, String artist, String album, int year, String genre, String comment, String filepath) {
//        this.id = id;
//        this.title = title;
//        this.artist = artist;
//        this.album = album;
//        this.year = year;
//        this.genre = genre;
//        this.comment = comment;
//        this.filepath = filepath;
//    }
//
//    // Getters and Setters for each field
//    // (Omitted for brevity)
// // Getters
//    public int getId() {
//        return id;
//    }
//
//    public String getTitle() {
//        return title;
//    }
//
//    public String getArtist() {
//        return artist;
//    }
//
//    public String getAlbum() {
//        return album;
//    }
//
//    public int getYear() {
//        return year;
//    }
//
//    public String getGenre() {
//        return genre;
//    }
//
//    public String getComment() {
//        return comment;
//    }
//
//    public String getFilepath() {
//        return filepath;
//    }
//
//    // Setters
//    public void setId(int id) {
//        this.id = id;
//    }
//
//    public void setTitle(String title) {
//        this.title = title;
//    }
//
//    public void setArtist(String artist) {
//        this.artist = artist;
//    }
//
//    public void setAlbum(String album) {
//        this.album = album;
//    }
//
//    public void setYear(int year) {
//        this.year = year;
//    }
//
//    public void setGenre(String genre) {
//        this.genre = genre;
//    }
//
//    public void setComment(String comment) {
//        this.comment = comment;
//    }
//
//    public void setFilepath(String filepath) {
//        this.filepath = filepath;
//    }
//}
//
//
//
//public class Song {
//    private int id;
//    private String title;
//    private String artist;
//    private String album;
//    private int year;
//    private String genre;
//    private String comment;
//    private String filepath;
//
//    public Song(int id, String title, String artist, String album, int year, String genre, String comment, String filepath) {
//        this.id = id;
//        this.title = title;
//        this.artist = artist;
//        this.album = album;
//        this.year = year;
//        this.genre = genre;
//        this.comment = comment;
//        this.filepath = filepath;
//    }
//
//    // Getters and Setters for each field
//    public int getId() { return id; }
//    public String getTitle() { return title; }
//    public String getArtist() { return artist; }
//    public String getAlbum() { return album; }
//    public int getYear() { return year; }
//    public String getGenre() { return genre; }
//    public String getComment() { return comment; }
//    public String getFilepath() { return filepath; }
//
//    public void setId(int id) { this.id = id; }
//    public void setTitle(String title) { this.title = title; }
//    public void setArtist(String artist) { this.artist = artist; }
//    public void setAlbum(String album) { this.album = album; }
//    public void setYear(int year) { this.year = year; }
//    public void setGenre(String genre) { this.genre = genre; }
//    public void setComment(String comment) { this.comment = comment; }
//    public void setFilepath(String filepath) { this.filepath = filepath; }
//}

//public class Song {
//    private int id;
//    private String title;
//    private String artist;
//    private String album;
//    private int year;
//    private String genre;
//    private String comment;
//    private String filepath;
//
//    public Song(int id, String title, String artist, String album, int year, String genre, String comment, String filepath) {
//        this.id = id;
//        this.title = title;
//        this.artist = artist;
//        this.album = album;
//        this.year = year;
//        this.genre = genre;
//        this.comment = comment;
//        this.filepath = filepath;
//    }
//
//    // Getters and Setters for each field
//    public int getId() { return id; }
//    public String getTitle() { return title; }
//    public String getArtist() { return artist; }
//    public String getAlbum() { return album; }
//    public int getYear() { return year; }
//    public String getGenre() { return genre; }
//    public String getComment() { return comment; }
//    public String getFilepath() { return filepath; }
//
//    public void setId(int id) { this.id = id; }
//    public void setTitle(String title) { this.title = title; }
//    public void setArtist(String artist) { this.artist = artist; }
//    public void setAlbum(String album) { this.album = album; }
//    public void setYear(int year) { this.year = year; }
//    public void setGenre(String genre) { this.genre = genre; }
//    public void setComment(String comment) { this.comment = comment; }
//    public void setFilepath(String filepath) { this.filepath = filepath; }
//}

public class Song {
    private int id; // If you are using IDs for database management
    private String title;
    private String artist;
    private String album;
    private int year;
    private String genre;
    private String comment;
    private String filepath;

    // Constructor with all fields
    public Song(String title, String artist, String album, int year, String genre, String comment, String filepath) {
        this.title = title;
        this.artist = artist;
        this.album = album;
        this.year = year;
        this.genre = genre;
        this.comment = comment;
        this.filepath = filepath;
    }

    // Constructor with ID, if you need it for database purposes
    public Song(int id, String title, String artist, String album, int year, String genre, String comment, String filepath) {
        this.id = id;
        this.title = title;
        this.artist = artist;
        this.album = album;
        this.year = year;
        this.genre = genre;
        this.comment = comment;
        this.filepath = filepath;
    }

    // Getters and setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getAlbum() {
        return album;
    }

    public void setAlbum(String album) {
        this.album = album;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getFilepath() {
        return filepath;
    }

    public void setFilepath(String filepath) {
        this.filepath = filepath;
    }
}



